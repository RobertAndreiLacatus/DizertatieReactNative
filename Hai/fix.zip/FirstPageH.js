import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  SafeAreaView,
  ScrollView,
  ImageBackground,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
  Modal,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Calendar } from 'react-native-calendars';
import * as ImagePicker from 'expo-image-picker';
import axios from 'axios'
import { API_URL } from '../HttpService';

export default function FirstPageHost() {
  const navigation = useNavigation();

  const [selectedDates, setSelectedDates] = useState({});
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [cardTitle, setCardTitle] = useState('');
  const [cardImage, setCardImage] = useState('');
  const [cardDescription, setCardDescription] = useState('');
  const [cards, setCards] = useState([]);
  
  useEffect(() => {
    fetchCards();
  }, []);
  

  const fetchCards = async () => {
    try {
      const response = await axios.get(API_URL + '/get_cards');
      const data = response.data;
      const cards = data['cards']
      setCards(cards);
    } catch (error) {
      console.log('Error fetching cards:', error);
    }
  };
  

  const handleDateSelection = (date) => {
    const selected = { ...selectedDates };

    // Toggle the selection of the date
    if (selected[date]) {
      delete selected[date];
    } else {
      selected[date] = { selected: true };
    }

    setSelectedDates(selected);
  };

  const handleCardCreation = () => {
    setIsModalVisible(true);
  };

  // React Native code

// ...

const handleSaveCard = async () => {
  try {
    const response = await axios.post(API_URL + '/add_card', {
      title: cardTitle,
      description: cardDescription,
      image: cardImage,
    });
    console.log('Card saved:', response.data);
    // Reset the card details and close the modal
    setCardTitle('');
    setCardImage('');
    setCardDescription('');
    setIsModalVisible(false);
    // Fetch the updated cards from the backend API
    fetchCards();
  } catch (error) {
    console.log('Error saving card:', error);
  }
};


  
  
  const handleImageSelection = async () => {
    const options = {
      title: 'Select Image',
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    };
  
    try {
      const response = await ImagePicker.launchImageLibraryAsync(options);
      if (!response.cancelled) {
        console.log("RESPONSE URI IMAGE", response.assets[0].uri)
        setCardImage(response.assets[0].uri);
      }
    } catch (error) {
      console.log('Image picker error:', error);
    }
  };
  

  return (
    <ScrollView style={styles.container}>
      <View>
        <Text style={styles.title}>Welcome to Host Page</Text>
        <Text style={styles.booked}>Your Booked Periods</Text>
        <Calendar
          style={styles.calendar}
          current={'2023-06-01'}
          markedDates={{
            ...selectedDates,
            '2023-06-15': { selected: true, marked: true },
            '2023-06-16': { selected: true, marked: true },
            '2023-06-17': { selected: true, marked: true },
            '2023-06-18': { selected: true, marked: true },
          }}
          onDayPress={(day) => handleDateSelection(day.dateString)}
        />
        <TouchableOpacity
          style={styles.addButton}
          onPress={handleCardCreation}
        >
          <Text style={styles.addButtonText}>Add Card</Text>
        </TouchableOpacity>

        <Modal visible={isModalVisible} animationType="slide">
          <SafeAreaView>
            <ScrollView contentContainerStyle={styles.modalContainer}>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setIsModalVisible(false)}
              >
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Title:</Text>
                <TextInput
                  style={styles.input}
                  value={cardTitle}
                  onChangeText={setCardTitle}
                />
              </View>
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Description:</Text>
                <TextInput
                  style={styles.input}
                  value={cardDescription}
                  onChangeText={setCardDescription}
                />
              </View>
              <TouchableOpacity
                style={styles.selectImageButton}
                onPress={handleImageSelection}
              >
                <Text style={styles.selectImageButtonText}>Select Image</Text>
              </TouchableOpacity>
              {cardImage !== '' && (
                <Image
                  source={{ uri: cardImage }}
                  style={styles.selectedImage}
                />
              )}
              <TouchableOpacity
                style={styles.saveButton}
                onPress={handleSaveCard}
              >
                <Text style={styles.saveButtonText}>Save</Text>
              </TouchableOpacity>
            </ScrollView>
          </SafeAreaView>
        </Modal>

        {cards.map((card, index) => {
          // <View key={index} style={styles.cardContainer}>
          //   <ImageBackground
          //     source={{ uri: cardImage }}
          //     style={styles.cardImage}
          //   >
          //     <Text style={styles.cardTitle}>{cardTitle}</Text>
          //     <Text style={styles.cardDescription}>{cardDescription}</Text>
          //   </ImageBackground>
          // </View>
          console.log("CARD", card)
          return (
          <View key={index}>
            <ImageBackground
              source={{ uri: card["image"] }}
              style={styles.cardImage}
            >
              <Text style={styles.cardTitle}>{card["title"]}</Text>
              <Text style={styles.cardDescription}>{card["description"]}</Text>
            </ImageBackground>
          </View>
        )})}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  booked: {
    fontSize: 18,
    marginBottom: 10,
  },
  calendar: {
    marginBottom: 20,
  },
  addButton: {
    backgroundColor: '#009688',
    padding: 10,
    borderRadius: 5,
    marginBottom: 20,
    alignItems: 'center',
  },
  addButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalContainer: {
    padding: 20,
  },
  closeButton: {
    backgroundColor: '#009688',
    padding: 10,
    borderRadius: 5,
    marginBottom: 20,
    alignItems: 'center',
  },
  closeButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
  },
  selectImageButton: {
    backgroundColor: '#009688',
    padding: 10,
    borderRadius: 5,
    marginBottom: 20,
    alignItems: 'center',
  },
  selectImageButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedImage: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
    marginBottom: 20,
  },
  saveButton: {
    backgroundColor: '#009688',
    padding: 10,
    borderRadius: 5,
    marginBottom: 20,
    alignItems: 'center',
  },
  saveButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cardContainer: {
    marginBottom: 20,
  },
  cardImage: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
    justifyContent: 'flex-end',
    padding: 10,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 5,
  },
  cardDescription: {
    fontSize: 16,
    color: 'white',
  },
});
